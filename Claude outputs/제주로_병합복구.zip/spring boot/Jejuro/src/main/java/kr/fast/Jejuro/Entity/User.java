package kr.fast.Jejuro.Entity;


//[공통]

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import org.hibernate.annotations.DynamicUpdate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Table;

/** 여행·커뮤니티에서 필요한 회원 정보만 읽는다. 회원가입 기능에서 필드를 더 채운다. */
@Entity
@DynamicUpdate   // 바뀐 칼럼만 UPDATE 
@Table(name = "`USER`")   // USER는 MySQL 예약어와 겹치므로 백틱으로 감싼다
public class User {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long userId;

 @Column(nullable = false)
 private String email;

 @JsonIgnore
 @Column(name = "password_hash", nullable = false)
 private String passwordHash;

 @Column(nullable = false)
 private String nickname;

 @Column(nullable = false)
 private LocalDate birthDate;

 @Column(nullable = false)
 private Integer genderCode;

 @Column(nullable = false)
 private String status;

 @Column(name = "withdrawn_at")
 private LocalDateTime withdrawnAt;

 /** USER 일반 회원 / ADMIN 관리자 (관리자 화면 접근) */
 @Column(nullable = false)
 private String role;

 protected User() {
 }

 public static User register(String email, String passwordHash, String nickname, LocalDate birthDate, Integer genderCode) {
     User user = new User();
     user.email = email;
     user.passwordHash = passwordHash;
     user.nickname = nickname;
     user.birthDate = birthDate;
     user.genderCode = genderCode;
     user.status = "ACTIVE";
     user.role = "USER";
     return user;
 }

 @JsonIgnore
 public String getPasswordHash() { return passwordHash; }

 public void requestWithdrawal() {
     status = "WITHDRAWAL_PENDING";
     withdrawnAt = LocalDateTime.now();
 }
 public LocalDateTime getWithdrawnAt() { return withdrawnAt; }

 public Long getUserId() { return userId; }
 public String getEmail() { return email; }
 public String getNickname() { return nickname; }
 public LocalDate getBirthDate() { return birthDate; }
 public Integer getGenderCode() { return genderCode; }
 public String getStatus() { return status; }
 public String getRole() { return role; }

 public boolean isAdmin() {
     return "ADMIN".equals(role);
 }
}